CREATE VIEW balance_current_student AS
  SELECT DISTINCT
    `hall`.`student`.`id`      AS `id`,
    `hall`.`room`.`cost`       AS `cost`,
    `hall`.`student`.`balance` AS `balance`
  FROM ((`hall`.`stays`
    LEFT JOIN `hall`.`student` ON ((`hall`.`stays`.`id` = `hall`.`student`.`id`))) JOIN `hall`.`room`)
  WHERE ((`hall`.`student`.`id` = `hall`.`stays`.`id`) AND (`hall`.`stays`.`year` = year(curdate())));

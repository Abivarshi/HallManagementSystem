CREATE VIEW student_stay AS
  SELECT
    `hall`.`stays`.`id`          AS `id`,
    `hall`.`person`.`first_name` AS `first_name`,
    `hall`.`person`.`last_name`  AS `last_name`,
    `hall`.`stays`.`hall_id`     AS `hall_id`,
    `hall`.`hall`.`name`         AS `name`,
    `hall`.`stays`.`room_number` AS `room_number`,
    `hall`.`stays`.`year`        AS `year`
  FROM ((`hall`.`hall`
    JOIN `hall`.`stays` ON ((`hall`.`stays`.`hall_id` = `hall`.`hall`.`hall_id`))) JOIN `hall`.`person`
      ON ((`hall`.`stays`.`id` = `hall`.`person`.`id`)));
